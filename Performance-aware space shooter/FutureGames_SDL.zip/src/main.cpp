#include <stdio.h>

int main()
{
	printf("Emil is the man\n");
}